import sqlite3

conn = sqlite3.connect('db.sqlite3')  # Sesuaikan dengan nama database Anda
cursor = conn.cursor()

cursor.execute("DROP TABLE IF EXISTS socialaccount_socialaccount")
cursor.execute("DROP TABLE IF EXISTS socialaccount_socialapp")
cursor.execute("DROP TABLE IF EXISTS socialaccount_socialtoken")

conn.commit()
conn.close()
