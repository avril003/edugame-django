"""
Nama file: add_docstring.py
Deskripsi: 
- Jelaskan tujuan dari file ini.
- Berikan gambaran umum tentang fungsionalitas yang ada di dalam file ini.
"""

import os

# Template docstring yang akan ditambahkan ke setiap file Python
docstring_template = '''"""
Nama file: {filename}
Deskripsi: 
- Jelaskan tujuan dari file ini.
- Berikan gambaran umum tentang fungsionalitas yang ada di dalam file ini.
"""
'''

def add_docstring_to_file(file_path):
    with open(file_path, 'r+', encoding='utf-8') as file:
        content = file.read()
        if not content.strip().startswith('"""'):
            docstring = docstring_template.format(filename=os.path.basename(file_path))
            file.seek(0, 0)
            file.write(docstring + '\n' + content)

def add_docstrings_to_directory(directory):
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                add_docstring_to_file(file_path)

# Path ke direktori proyek Anda
project_directory = 'D:\\SEMESTER 6\\SIB\\Back End\\edugame\\django'
add_docstrings_to_directory(project_directory)
