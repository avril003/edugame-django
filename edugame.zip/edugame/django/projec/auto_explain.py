"""
Nama file: auto_explain.py
Deskripsi:
- Tujuan: Template docstring yang akan ditambahkan ke setiap file Python      Menggabungkan semua komentar menjadi satu kalimat deskriptif      Mendapatkan daftar fungsi yang ada dalam file          Analisis AST  Path ke direktori proyek Anda
- Fungsi: get_purpose_from_comments, get_functions_from_ast, add_docstring_to_file, add_docstrings_to_directory
"""


import os
import ast

# Template docstring yang akan ditambahkan ke setiap file Python
docstring_template = '''"""
Nama file: {filename}
Deskripsi:
- Tujuan: {purpose}
- Fungsi: {functions}
"""
'''

def get_purpose_from_comments(comments):
    # Menggabungkan semua komentar menjadi satu kalimat deskriptif
    return ' '.join(comments).replace('#', '').strip()

def get_functions_from_ast(tree):
    # Mendapatkan daftar fungsi yang ada dalam file
    return [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]

def add_docstring_to_file(file_path):
    with open(file_path, 'r+', encoding='utf-8') as file:
        content = file.read()
        
        # Analisis AST
        tree = ast.parse(content)
        comments = [line for line in content.splitlines() if line.strip().startswith('#')]
        
        purpose = get_purpose_from_comments(comments) if comments else "Tidak ada deskripsi yang ditemukan."
        functions = ', '.join(get_functions_from_ast(tree)) if tree else "Tidak ada fungsi yang ditemukan."

        if not content.strip().startswith('"""'):
            docstring = docstring_template.format(filename=os.path.basename(file_path), purpose=purpose, functions=functions)
            file.seek(0, 0)
            file.write(docstring + '\n' + content)

def add_docstrings_to_directory(directory):
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                add_docstring_to_file(file_path)

# Path ke direktori proyek Anda
project_directory = 'D:\\SEMESTER 6\\SIB\\Back End\\edugame\\django'
add_docstrings_to_directory(project_directory)
