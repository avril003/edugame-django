var count = 0;
var animTimeout = null;
var achievementBadge = $(".ach");

$(".btn").click(function () {
  if (count == 0) {
    $(".title").text("Click Master!");
    $(".detail").text("You clicked the button 1 time");
    achieve();
  }
  count = count + 1;
  $(".count").text(count);
  $(this).off('click');  // Menonaktifkan event click setelah klik pertama
});

function achieve() {
  achievementBadge.removeClass("achieved");
  setTimeout(function () {
    achievementBadge.addClass("achieved");
  }, 1);
}
