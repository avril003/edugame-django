// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Which of the following is correct about features of JavaScript?",
    answer: "All of the above.",
    options: [
      "JavaScript is a lightweight, interpreted programming language",
      "JavaScript is designed for creating network-centric applications",
      "JavaScript is complementary to and integrated with Java.",
      "All of the above."
    ]
  },
  {
    numb: 2,
    question: "Which of the following function of String object returns the characters in a string between two indexes into the string?",
    answer: "substring()",
    options: [
      "slice()",
      "split()",
      "substr()",
      "substring()"
    ]
  },
  {
    numb: 3,
    question: "Which of the following function of String object creates an HTML anchor that is used as a hypertext target?",
    answer: "anchor()",
    options: [
      "anchor()",
      "link()",
      "blink()",
      "big()"
    ]
  },
  {
    numb: 4,
    question: "Which of the following function of Array object represents the source code of an object?",
    answer: "toSource()",
    options: [
      "toSource()",
      "splice()",
      "toString()",
      "unshift()"
    ]
  },
  {
    numb: 5,
    question: "Which built-in method returns the calling string value converted to lower case?",
    answer: "toLowerCase()",
    options: [
      "toLowerCase()",
      "toLower()",
      "changeCase(case)",
      "None of the above."
    ]
  },
  // {
  //   numb: 6,
  //   question: "What does HTML stand for?",
  //   answer: "Hyper Text Markup Language",
  //   options: [
  //     "Hyper Text Preprocessor",
  //     "Hyper Text Markup Language",
  //     "Hyper Text Multiple Language",
  //     "Hyper Tool Multi Language"
  //   ]
  // },
  // {
  //   numb: 7,
  //   question: "What does HTML stand for?",
  //   answer: "Hyper Text Markup Language",
  //   options: [
  //     "Hyper Text Preprocessor",
  //     "Hyper Text Markup Language",
  //     "Hyper Text Multiple Language",
  //     "Hyper Tool Multi Language"
  //   ]
  // },
  // {
  //   numb: 8,
  //   question: "What does HTML stand for?",
  //   answer: "Hyper Text Markup Language",
  //   options: [
  //     "Hyper Text Preprocessor",
  //     "Hyper Text Markup Language",
  //     "Hyper Text Multiple Language",
  //     "Hyper Tool Multi Language"
  //   ]
  // },
  // {
  //   numb: 9,
  //   question: "What does HTML stand for?",
  //   answer: "Hyper Text Markup Language",
  //   options: [
  //     "Hyper Text Preprocessor",
  //     "Hyper Text Markup Language",
  //     "Hyper Text Multiple Language",
  //     "Hyper Tool Multi Language"
  //   ]
  // },
  // {
  //   numb: 10,
  //   question: "What does HTML stand for?",
  //   answer: "Hyper Text Markup Language",
  //   options: [
  //     "Hyper Text Preprocessor",
  //     "Hyper Text Markup Language",
  //     "Hyper Text Multiple Language",
  //     "Hyper Tool Multi Language"
  //   ]
  // },

];