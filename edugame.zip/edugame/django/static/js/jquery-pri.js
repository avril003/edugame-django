$(document).ready(function(){
    $('#searchIcon').on('click', function(){
        filterCards();
    });

    $('#searchInput').on('keyup', function(e){
        if (e.keyCode === 13) { // Check if Enter key is pressed
            filterCards();
        }
    });

    function filterCards() {
        var searchText = $('#searchInput').val().toLowerCase();
        $('.info').each(function(){
            var cardText = $(this).find('h3').text().toLowerCase();
            var card = $(this).parent();
            if (cardText.includes(searchText)) {
                card.show();
            } else {
                card.hide();
            }
        });
    }
});
