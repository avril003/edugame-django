from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("about/", views.about, name="about"),
    path("packages/", views.packages, name="packages"),
    path("gallery/", views.gallery, name="gallery"),
    path("pricing/", views.pricing, name="pricing"),
    path("contact/", views.contact, name="contact"),
    path("accounts_login/", views.accounts, name="accounts"),
    path("signup/", views.signup, name="signup"),
    path("logout/", views.logout_view, name="logout"),
    path('kelas/<int:pk>/', views.kelas_view, name='kelas_view'),
    path('kelas/<int:pk>/<str:jenis_materi>/', views.kelas_view, name='kelas_view_with_materi'),
    path('materi/<int:materi_id>/', views.materi_detail, name='materi_detail'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path("premium/", views.premium, name="premium"),
    path('free/<int:materi_id>/', views.free_materi, name='free_materi'),
    path('premium/<int:materi_id>/', views.premium_materi, name='premium_materi'),
    path("nilai/", views.nilai, name="nilai"),
    path("profile/", views.profile, name="profile"),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
