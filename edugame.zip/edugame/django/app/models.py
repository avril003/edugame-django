from django.db import models
from django.contrib.auth.models import User
import random
import string
from django.urls import reverse

def generate_random_code():
    length = 6
    while True:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))
        if not Materi.objects.filter(kode=code).exists():
            break
    return code

class Kelas(models.Model):
    name = models.CharField(max_length=100)
    type = models.CharField(max_length=100, default="Asynchronous", editable=False)
    course_details = models.TextField()
    course_structure = models.TextField()
    detail = models.TextField()
    image = models.ImageField(upload_to="products/", blank=True, null=True)

    def __str__(self):
        return self.name

class Materi(models.Model):
    LEVEL_CHOICES = [
        ('Free', 'Free'),
        ('Premium', 'Premium'),
    ]
    image = models.ImageField(upload_to="materi/", blank=True, null=True)
    kelas = models.ForeignKey(Kelas, on_delete=models.CASCADE, related_name='materi')
    nama = models.CharField(max_length=100)
    kode = models.CharField(max_length=6, unique=True, default=generate_random_code, editable=False)
    detail = models.TextField()
    jadul_materi1 = models.TextField(blank=True, null=True)
    isi1_materi = models.TextField(blank=True, null=True)
    jadul_materi2 = models.TextField(blank=True, null=True)
    isi2_materi = models.TextField(blank=True, null=True)
    level = models.CharField(max_length=7, choices=LEVEL_CHOICES, default='Free')
    video_url_1 = models.URLField(max_length=200, blank=True, null=True)
    video_url_2 = models.URLField(max_length=200, blank=True, null=True)

    def __str__(self):
        return self.nama

class Kelma(models.Model):
    kelas = models.ForeignKey(Kelas, on_delete=models.CASCADE)
    materi = models.ForeignKey(Materi, related_name='materi_as_materi', on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    nilai = models.DecimalField(max_digits=5, decimal_places=0, default=0.00)
    quiz = models.ForeignKey(Materi, on_delete=models.CASCADE, related_name='quiz', null=True, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.kelas.name} - {self.materi.nama}"
    

    
    
class Achievement(models.Model):
    materi = models.ForeignKey(Materi, on_delete=models.CASCADE, related_name='achievements')
    min_score = models.IntegerField()
    max_score = models.IntegerField()
    image = models.ImageField(upload_to="achivment/", blank=True, null=True)

    def __str__(self):
        return f"Achievement for {self.materi.nama} from {self.min_score} to {self.max_score}"
    
    

def default_profile_image():
    return "https://bootdey.com/img/Content/avatar/avatar7.png"

class Akun(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    email = models.EmailField(max_length=255, unique=True)
    LEVEL_CHOICES = [
        ("Siswa", "Siswa"),
        ("Guru", "Guru"),
    ]
    level = models.CharField(max_length=10, choices=LEVEL_CHOICES)
    profile_image = models.ImageField(upload_to='profile_images/', blank=True, null=True, default=default_profile_image)

    def __str__(self):
        return self.user.username
    

class Testimonial(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    position = models.CharField(max_length=100)
    message = models.TextField()

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class Team(models.Model):
    POSITION_CHOICES = [
        ("President & Founder", "President & Founder"),
        ("CEO", "CEO"),
        ("Co-Founder", "Co-Founder"),
        ("Associate Manager", "Associate Manager"),
        ("Program Development Manager", "Program Development Manager"),
        ("IT Manager", "IT Manager"),
        ("Operational Manager", "Operational Manager"),
        ("Sales & Marketing Manager", "Sales & Marketing Manager"),
        ("Business Development Manager", "Business Development Manager"),
    ]

    name = models.CharField(max_length=100, default="Unnamed")
    position = models.CharField(max_length=100, choices=POSITION_CHOICES, default="Associate Manager")
    image = models.ImageField(upload_to="persons/", blank=True, null=True)

    def __str__(self):
        return self.name
