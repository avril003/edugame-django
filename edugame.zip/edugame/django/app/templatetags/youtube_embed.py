import re
from django import template

register = template.Library()

@register.filter(name='youtube_embed')
def youtube_embed(value):
    pattern = re.compile(r'(https?://)?(www\.)?(youtube|youtu|youtube-nocookie)\.(com|be)/(watch\?v=|embed/|v/|.+\?v=)?([^&=%\?]{11})')
    match = pattern.match(value)
    if match:
        video_id = match.group(6)
        embed_url = f'https://www.youtube.com/embed/{video_id}'
        return embed_url
    return value
