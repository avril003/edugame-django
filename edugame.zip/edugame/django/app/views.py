from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from .forms import SignUpForm, EditProfileForm, EditAkunForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
import logging
import random
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from .models import Kelas, Testimonial, Team, Akun, Kelma  ,Materi# Ensure Akun is imported
from django.contrib import messages

logger = logging.getLogger(__name__)

# putri
def index(request):
    testimonials = Testimonial.objects.all()
    return render(request, "index.html", {"testimonials": testimonials})

def about(request):
    team_members = Team.objects.all()

    # Urutan berdasarkan posisi
    ordered_positions = [
        "President & Founder",
        "CEO",
        "Co-Founder",
        "Associate Manager",
        "Program Development Manager",
        "IT Manager",
        "Operational Manager",
        "Sales & Marketing Manager",
        "Business Development Manager",
    ]

    # Urutkan team members berdasarkan posisi
    team_members = sorted(
        team_members,
        key=lambda x: (
            ordered_positions.index(x.position)
            if x.position in ordered_positions
            else len(ordered_positions)
        ),
    )

    # Daftar warna yang tersedia
    colors = ["yellow", "blue", "green", "red", "purple", "orange"]

    # Tambahkan atribut warna acak untuk setiap team member
    for member in team_members:
        member.color = random.choice(colors)

    return render(request, "about.html", {'teams': team_members})

# nensi
def pricing(request):
    kelas_list = Kelas.objects.all()
    testimonials = Testimonial.objects.all()
    context = {
        'kelas_list': kelas_list,
        "testimonials": testimonials,
    }
    return render(request, "pricing.html", context)

def contact(request):
    if request.method == "POST":
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        position = request.POST.get("position")
        message = request.POST.get("message")

        testimonial = Testimonial(
            first_name=first_name,
            last_name=last_name,
            position=position,
            message=message,
        )
        testimonial.save()
        return redirect("contact")
    testimonials = Testimonial.objects.all()
    return render(request, "contact.html", {"testimonials": testimonials})

def accounts(request):
    logger.debug("Masuk ke view login")
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        logger.debug("Form POST diterima")
        if form.is_valid():
            logger.debug("Form valid")
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            logger.debug(f"Mencoba otentikasi pengguna: {username}")
            user = authenticate(request, username=username, password=password)
            if user is not None:
                logger.debug(f"Pengguna berhasil diotentikasi: {username}")
                login(request, user)
                messages.success(request, f"Selamat datang, {username}!")
                logger.debug(f"Mengalihkan {username} ke index")
                return redirect('dashboard')  # Atau 'dashboard' jika Anda ingin mengarahkan ke dashboard
            else:
                logger.warning(f"Pengguna {username} tidak ditemukan atau password salah.")
                messages.error(request, "Nama pengguna atau kata sandi tidak valid.")
        else:
            logger.error(f"Form tidak valid: {form.errors}")
            messages.error(request, "Harap periksa kembali input Anda.")
    else:
        logger.debug("GET request diterima, menampilkan form login")
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})


# nabila
def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)
            messages.success(request, 'Akun Anda telah berhasil dibuat!')
            return redirect('accounts')
        else:
            messages.error(request, 'Harap perbaiki kesalahan di bawah ini.')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})

def packages(request):
    testimonials = Testimonial.objects.all()
    return render(request, "packages.html", {"testimonials": testimonials})

def gallery(request):
    return render(request, "gallery.html")


@login_required
def dashboard(request):
    user = request.user
    
    # Mengambil semua kelas yang diambil oleh user
    kelma_list = Kelma.objects.filter(user=user)
    total_kelas = kelma_list.values('kelas').distinct().count()
    total_materi = kelma_list.values('materi').distinct().count()
    total_quiz = kelma_list.exclude(nilai=0).count()  # Menghitung kuis yang sudah dikerjakan (nilai != 0)
    kelas_list = Kelas.objects.all()  # Mengambil semua kelas dari database

    context = {
        'kelas_list': kelas_list,
        'total_kelas': total_kelas,
        'total_materi': total_materi,
        'total_quiz': total_quiz,
    }

    return render(request, 'Tampilan/dalam.html', context)



@login_required
def kelas_view(request, pk):
    course = get_object_or_404(Kelas, pk=pk)
    materi_list = course.materi.all()
    user_kelma = Kelma.objects.filter(user=request.user, kelas=course).values_list('materi_id', flat=True)

    context = {
        'course': course,
        'materi_list': materi_list,
        'user_kelma': user_kelma,
    }
    return render(request, 'Tampilan/kelas.html', context)


@login_required
def materi_detail(request, materi_id):
    materi = get_object_or_404(Materi, id=materi_id)
    user_has_taken_materi = Kelma.objects.filter(user=request.user, materi=materi).exists()
    
    if materi.level == 'Premium' and not user_has_taken_materi:
        messages.error(request, 'Anda belum mengambil materi ini. Silakan masukkan kode untuk mengakses materi Premium.')
        return redirect('premium_materi', materi_id=materi.id)
    
    videos = [materi.video_url_1, materi.video_url_2]
    videos = [video for video in videos if video]  # Filter out empty video URLs
    return render(request, 'materi/materi_detail.html', {'materi': materi, 'videos': videos})


@login_required
def free_materi(request, materi_id):
    materi = get_object_or_404(Materi, id=materi_id, level='Free')
    kelma, created = Kelma.objects.get_or_create(
        user=request.user,
        kelas=materi.kelas,
        materi=materi,
        quiz=materi
    )
    if created:
        messages.success(request, f'Materi {materi.nama} berhasil diambil.')
    else:
        messages.info(request, f'Anda sudah mengambil materi {materi.nama}.')
    return redirect('materi_detail', materi_id=materi.id)

@login_required
def premium_materi(request, materi_id):
    materi = get_object_or_404(Materi, id=materi_id, level='Premium')
    if request.method == "POST":
        input_code = request.POST.get('code')
        if input_code == materi.kode:
            kelma, created = Kelma.objects.get_or_create(
                user=request.user,
                kelas=materi.kelas,
                materi=materi,
                quiz=materi
            )
            if created:
                messages.success(request, f'Materi "{materi.nama}" berhasil diambil.')
            else:
                messages.info(request, f'Anda sudah mengambil materi "{materi.nama}".')
            return redirect('materi_detail', materi_id=materi.id)
        else:
            messages.error(request, 'Kode tidak valid.')
    context = {
        'materi': materi
    }
    return render(request, 'Tampilan/premium.html', context)

@login_required
def premium(request):
    context = {}
    if request.method == "POST":
        input_code = request.POST.get('code')
        try:
            materi = Materi.objects.get(kode=input_code, level='Premium')
            kelas = materi.kelas

            kelma, created = Kelma.objects.get_or_create(
                user=request.user,
                kelas=kelas,
                materi=materi
            )

            context = {
                'success_message': f'Materi "{materi.nama}" dari kelas "{kelas.name}" berhasil diambil.',
                'success': True,
                'input_code': input_code
            }
            return redirect('materi_detail', materi_id=materi.id)
        except Materi.DoesNotExist:
            context = {
                'error_message': 'Kode tidak valid atau bukan materi Premium.',
                'input_code': input_code
            }
    else:
        context = {}

    return render(request, 'Tampilan/premium.html', context)


@login_required
def nilai(request):
    user = request.user
    kelma_list = Kelma.objects.filter(user=user)
    kelas_dict = {}

    for kelma in kelma_list:
        kelas = kelma.kelas
        if kelas not in kelas_dict:
            kelas_dict[kelas] = []
        kelas_dict[kelas].append(kelma)
    
    context = {
        'kelas_dict': kelas_dict,
    }

    if not kelma_list:
        context['alert'] = 'Anda belum mengambil kelas dan materi.'

    return render(request, 'Tampilan/nilai.html', context)

@login_required
def profile(request):
    user = request.user
    kelma_list = Kelma.objects.filter(user=user)
    kelas_list = kelma_list.values_list('kelas__name', flat=True).distinct()
    materi_list = kelma_list.values_list('materi__nama', flat=True).distinct()
    
    if user.is_superuser:
        user_level = "-"
    else:
        user_level = user.akun.level

    # Get one of the highest quiz scores
    highest_kelma = kelma_list.order_by('-nilai').first()
    highest_score = highest_kelma.nilai if highest_kelma else None

    context = {
        'user': user,
        'user_level': user_level,
        'kelma_list': kelma_list,
        'kelas_count': len(kelas_list),
        'materi_count': len(materi_list),
        'akun': user.akun,
        'highest_score': highest_score,
    }

    return render(request, 'Tampilan/profile.html', context)

@login_required
def edit_profile(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        profile_image = request.FILES.get('profile_image')

        try:
            user = request.user
            user.username = username
            user.email = email
            user.save()

            akun = Akun.objects.get(user=user)
            if profile_image:
                akun.profile_image = profile_image
            akun.save()

            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method.'})


def logout_view(request):
    logout(request)
    return redirect("index")  # Mengarahkan pengguna ke halaman index setelah logout