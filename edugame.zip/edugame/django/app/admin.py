from django.contrib import admin
from .models import Kelas, Materi, Kelma, Achievement, Akun, Testimonial, Team

class MateriInline(admin.TabularInline):
    model = Materi
    extra = 1

class KelasAdmin(admin.ModelAdmin):
    list_display = ('name', 'type', 'course_details', 'course_structure', 'detail')
    inlines = [MateriInline]

class KelmaAdmin(admin.ModelAdmin):
    list_display = ('user', 'kelas', 'materi', 'nilai', 'quiz')


class AchievementAdmin(admin.ModelAdmin):
    list_display = ('materi', 'min_score', 'max_score', 'image')

class AkunAdmin(admin.ModelAdmin):
    list_display = ('user', 'email', 'level')

class TestimonialAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'position', 'message')

class TeamAdmin(admin.ModelAdmin):
    list_display = ('name', 'position', 'image')

admin.site.register(Kelas, KelasAdmin)
admin.site.register(Materi)
admin.site.register(Kelma, KelmaAdmin)
admin.site.register(Achievement, AchievementAdmin)
admin.site.register(Akun, AkunAdmin)
admin.site.register(Testimonial, TestimonialAdmin)
admin.site.register(Team, TeamAdmin)
