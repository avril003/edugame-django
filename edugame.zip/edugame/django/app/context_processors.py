from .models import Kelas

def kelas_list(request):
    return {
        'kelas_list': Kelas.objects.all()
    }
