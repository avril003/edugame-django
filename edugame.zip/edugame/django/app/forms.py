from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Akun, Testimonial
from django_recaptcha.fields import ReCaptchaField


# whidi,putri,nabila, rini
class SignUpForm(UserCreationForm):
    email = forms.EmailField(max_length=254, help_text='Wajib. Masukkan alamat email yang valid.')
    level = forms.ChoiceField(choices=Akun.LEVEL_CHOICES, help_text='Pilih level pengguna.')

    
    captcha = ReCaptchaField()
    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'level', 'captcha')
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
            akun = Akun.objects.create(
                user=user,
                email=self.cleaned_data['email'],
                level=self.cleaned_data['level']
            )
        return user


# medina
class TestimonialForm(forms.ModelForm):
    class Meta:
        model = Testimonial
        fields = ["first_name", "last_name", "email", "position", "message"]

class EditProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email']

class EditAkunForm(forms.ModelForm):
    class Meta:
        model = Akun
        fields = ['profile_image']