"""
Nama file: apps.py
Deskripsi:
- Tujuan: Tidak ada deskripsi yang ditemukan.
- Fungsi: 
"""


from django.apps import AppConfig


class AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app'
